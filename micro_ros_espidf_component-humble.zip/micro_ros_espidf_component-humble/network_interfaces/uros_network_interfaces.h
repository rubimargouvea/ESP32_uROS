#include "esp_system.h"

#ifdef __cplusplus
extern "C"
{
#endif

esp_err_t uros_network_interface_initialize(void);

#ifdef __cplusplus
}
#endif