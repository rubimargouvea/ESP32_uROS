// Include proper path to FreeRTOS header file
#include "freertos/semphr.h"