// This is very overkill, but it's a workaround for the fact that the ESP_STATIC_ASSERT fails when building micro-ROS in IDF >v5.0.0
