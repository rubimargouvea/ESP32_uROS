// Include proper path to FreeRTOS header file
#include "freertos/FreeRTOS.h"
